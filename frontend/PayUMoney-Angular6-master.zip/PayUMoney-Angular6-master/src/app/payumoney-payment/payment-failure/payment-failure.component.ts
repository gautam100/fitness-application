import {Component} from '@angular/core';

@Component({
  selector: 'app-payment-failure',
  templateUrl: 'payment-failure.component.html',
  styleUrls: ['payment-failure.component.scss']
})

export class PaymentFailureComponent {
  constructor() {}
}
