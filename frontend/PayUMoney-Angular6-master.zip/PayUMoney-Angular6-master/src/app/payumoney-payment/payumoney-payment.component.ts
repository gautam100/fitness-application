import {Component} from '@angular/core';

@Component({
  selector: 'app-payumoney-payment',
  templateUrl: 'payumoney-payment.component.html'
})

export class PayumoneyPaymentComponent {
  constructor() {}
}
