export const environment = {
  production: true,
  apiBaseUrl : 'http://localhost:8080/api'
};
