class User {
    public email: string;
    public firstName: string;
    public lastName: string;
    constructor() {}
}
export = User;
